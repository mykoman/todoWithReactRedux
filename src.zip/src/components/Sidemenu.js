import React from 'react';
import Drawer from '@material-ui/core/Drawer';
import { List, Divider, Button, Grid, Container, AppBar, Toolbar, IconButton, Typography, makeStyles } from '@material-ui/core';
import MyAppBar from './menubar';
import MenuIcon from '@material-ui/icons/Menu';
import { withStyles } from '@material-ui/styles';


const MyIconButton = withStyles({
  root: {color:
    'blue',
    width: '20'}, // a style rule
  label: {}, // a nested style rule
})(({ classes }) => (
  <IconButton
    edge="start"
    color="inherit"
    aria-label="open drawer"
    onClick={props.onClick}>
  
    <MenuIcon />
  </IconButton>
));

const MyDrawer = withStyles({
  root:{display: 'flex',
    width: '240px',
    color: 'yellow'},
  list:{ color: 'blue'}
})(({ classes }) => (
  <Drawer variant="temporary" className={classes.root} open="true" onClick={props.onClick}>
            
          <MyIconButton onClick={ props.onClick} />
            <List className={classes.list}>Item One</List>
            <Divider />
            <List>Item Two</List>
            <Divider />
            </Drawer>
));

class Sidemenu extends React.Component{
    constructor(props){
        super(props);
        this.state= {
            opendrawer: false,
        }
    }
    
    handleDrawerClose(){
        // alert('hi');
        const nextDrawerState = this.state.opendrawer ? false: true;
        this.setState({opendrawer: nextDrawerState});

    }
    
    render(){
        return (<div>
            <MyAppBar />
            
            <MyDrawer  onClick={this.handleDrawerClose} />
            <main>
           
            <Container>
                <Grid>
                    <Button variant="contained" onClick={ ()=> this.handleDrawerClose()}>Open Menu </Button>
                </Grid>
            </Container>
            </main>
        </div>);
    }
    
}
export default Sidemenu;