import React from 'react';
import MyAppBar from './menubar';
import Clock from './Clock';
import Board from './Board';
import Button from '@material-ui/core/Button';
import 'typeface-roboto';
import { Typography } from '@material-ui/core';
import Sidemenu from './Sidemenu';


class Game extends React.Component {
    render() {
      return (
        <div>
          {/* <Dashboard /> */}
          {/* <MyAppBar /> */}
          <Sidemenu />
          <Clock />
        <div className="game">
          <div className="game-board">
            <Board />
          </div>
          <div className="game-info">
            <div>{/* status */}</div>
            <ol>{/* TODO */}</ol>
          </div>
        </div>
          
          <Button variant="contained" color="primary"> Button</Button>
          <Typography variant="h6">H6 variant- H1 component</Typography>
        </div>
      );
    }
  }
  export default Game;