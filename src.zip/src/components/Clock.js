import React from 'react';

class Clock extends React.Component {
    constructor(props){
      super(props);
      this.state= {
        date: new Date(),
        name: "Mike",
      }
    }
    componentDidMount(){
      //this.timingID=setInterval(console.log('mike'), 1000);
      //console.log(this.timingID);
      this.timerID = setInterval(
        () => this.tick(),
        1000
      );
    }
    componentWillUnmount(){
      //clearInterval(this.tick(), 1000);
      clearInterval(this.timerID);
    }
    tick(){
      this.setState({date: new Date()})
    }
    render(){
      return (
      <div>
        <h1>Hello, {this.state.name}</h1>
        <h3>Time is {this.state.date.toLocaleTimeString()}</h3>
      </div>)
    }
    
  }

  export default Clock;