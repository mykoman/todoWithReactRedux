import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

// handleClick(){
//   alert('hi');
// };
export default function MyAppBar(props){

  return(
      <div>
        <AppBar>
          <Toolbar>
            <IconButton>
              <MenuIcon onClick={props.onClick} />
            </IconButton>
            <Typography>
              My App
            </Typography>
          </Toolbar>
        </AppBar>
      </div>
    );
  }
