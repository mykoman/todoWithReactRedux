import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import 'typeface-roboto';
import Game from './components/Game';

// class Square extends React.Component {
//     // constructor(props){
//     //     super(props);
//     //     this.state={
//     //         value: null,
//     //     }

//     // }
//     render() {
//       return (
//         <button className="square" 
//         onClick={()=> this.props.onClick()}>
//           {this.props.value}
//         </button>
//       );
//     }
//   }

//let's do a functional component rather than a class component

  
  
  
  // ========================================

  
  
  
  ReactDOM.render(
    <Game /> ,
    document.getElementById('root')
  );
  